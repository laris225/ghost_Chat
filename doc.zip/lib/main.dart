import 'package:flutter/material.dart';

import 'screen/introduction.dart';
import 'screen/connexion.dart';
import 'screen/confirme.dart';
import 'widget/widg_ghostChat.dart';
import 'screen/message.dart';
import 'screen/appelAudio.dart';
import 'screen/appelVideo.dart';
import 'screen/newmsg.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ghost Chat',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Introduction(),
      routes: {
        'connexion': (context) => Connexion(),
        'confirme': (context) => Confirme(),
        'homePage': (context) => Widg_GhostChat(),
        'message': (context) => Message(),
        'appelAudio': (context) => AppelAudio(),
        'appelVideo': (context) => AppelVideo(),
        'newMsg': (context) => NewMsg(),
      },
    );
  }
}
