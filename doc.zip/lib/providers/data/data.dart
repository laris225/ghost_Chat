List userData = [
  {
    "imgData": "images/1.png",
    "nameData": "Laris",
    "msgData": "Bonjour Laris, est-ce que t as fait l'exercice ?",
    "dateSendData": "12h15",
    "nmbData": "1",
  },
  {
    "imgData": "images/2.png",
    "nameData": "Ines",
    "msgData": "Bonjour Ines, est-ce que t as fait l'exercice ?",
    "dateSendData": "18h41",
    "nmbData": "2",
  },
  {
    "imgData": "images/3.png",
    "nameData": "Domi",
    "msgData": "Bonjour Domi, est-ce que t as fait l'exercice ?",
    "dateSendData": "15h17",
    "nmbData": "3",
  },
  {
    "imgData": "images/4.png",
    "nameData": "Sydney",
    "msgData": "Bonjour Sydney, est-ce que t as fait l'exercice ?",
    "dateSendData": "12h24",
    "nmbData": "1",
  },
  {
    "imgData": "images/5.png",
    "nameData": "Davy",
    "msgData": "Bonjour Davy, est-ce que t as fait l'exercice ?",
    "dateSendData": "9h15",
    "nmbData": "2",
  },
  {
    "imgData": "images/6.png",
    "nameData": "Cedric",
    "msgData": "Bonjour Cedric, est-ce que t as fait l'exercice ?",
    "dateSendData": "Hier",
    "nmbData": "4",
  },
  {
    "imgData": "images/7.png",
    "nameData": "Nath",
    "msgData": "Bonjour Nath, est-ce que t as fait l'exercice ?",
    "dateSendData": "Hier",
    "nmbData": "1",
  },
];

List messageData = [
  {
    "imgData": "images/1.png",
    "nameData": "Laris",
    "stautData": "En ligne",
  },
  {
    "imgData": "images/2.png",
    "nameData": "Ines",
    "stautData": "Il y a 1 jour",
  },
  {
    "imgData": "images/3.png",
    "nameData": "Domi",
    "stautData": "En ligne",
  },
  {
    "imgData": "images/4.png",
    "nameData": "Sydney",
    "stautData": "Il y a 18h15",
  },
  {
    "imgData": "images/5.png",
    "nameData": "Davy",
    "stautData": "En ligne",
  },
  {
    "imgData": "images/6.png",
    "nameData": "Cedric",
    "stautData": "45 minutes",
  },
  {
    "imgData": "images/7.png",
    "nameData": "Nath",
    "stautData": "Hier",
  },
];

// List imgData = [
//   "images/1.png",
//   "images/2.png",
//   "images/3.png",
//   "images/4.png",
//   "images/5.png",
//   "images/6.png",
//   "images/7.png",
// ];

// List nameData = [
//   "Laris",
//   "Ines",
//   "Domi",
//   "Sydney",
//   "Davy",
//   "Cedric",
//   "Nath",
// ];

// List msgData = [
//   "Bonjour Laris, est-ce que t as fait l'exercice ?",
//   "Bonjour Ines, est-ce que t as fait l'exercice ?",
//   "Bonjour Domi, est-ce que t as fait l'exercice ?",
//   "Bonjour Sydney, est-ce que t as fait l'exercice ?",
//   "Bonjour Davy, est-ce que t as fait l'exercice ?",
//   "Bonjour Cedric, est-ce que t as fait l'exercice ?",
//   "Bonjour Nath, est-ce que t as fait l'exercice ?",
// ];

// List dateSendData = [
//   "12h15",
//   "hier",
//   "22h11",
//   "hier",
//   "06h21",
//   "hier",
//   "18h32",
// ];

// List nmbData = [
//   "2",
//   "5",
//   "4",
//   "3",
//   "1",
//   "4",
//   "1",
// ];
