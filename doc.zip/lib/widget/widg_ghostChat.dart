import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../screen/ghostChat.dart';
import '../screen/utilisateurs.dart';
import '../screen/groupes.dart';
import '../screen/supergroupes.dart';
import '../screen/robots.dart';
import '../screen/favoris.dart';
import '../screen/message.dart';

Widget appBarM(String title) {
  return AppBar(
    backgroundColor: Color(0xff102128),
    elevation: 0,
    title: Text(title),
  );
}

class Widg_GhostChat extends StatefulWidget {
  @override
  _Widg_GhostChatState createState() => _Widg_GhostChatState();
}

class _Widg_GhostChatState extends State<Widg_GhostChat>
    with SingleTickerProviderStateMixin {
  TabController tabControler;
  @override
  void initState() {
    tabControler = new TabController(
      length: 6,
      vsync: this,
    );
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff102128),
        title: Text(
          'Ghost Chat',
          style: TextStyle(
              fontFamily: 'cursive', fontWeight: FontWeight.bold, fontSize: 35),
        ),
        actions: <Widget>[
          IconButton(icon: Icon(Icons.search), iconSize: 25, onPressed: () {}),
          IconButton(
              icon: Icon(Icons.folder_open), iconSize: 25, onPressed: () {}),
        ],
        bottom: TabBar(
          indicatorColor: Color(0XFFFFFFFF),
          indicatorSize: TabBarIndicatorSize.tab,
          unselectedLabelColor: Colors.grey,
          labelColor: Color(0XFFFFFFFF),
          controller: tabControler,
          tabs: [
            Tab(
              icon: Icon(
                Icons.home,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.person_outline,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.people_outline,
              ),
            ),
            Tab(
              icon: Icon(
                FontAwesomeIcons.users,
                size: 18,
              ),
            ),
            Tab(
              icon: Icon(
                FontAwesomeIcons.robot,
                size: 18,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.star_border,
                size: 25,
              ),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabControler,
        children: [
          GhostChat(),
          Utilisateurs(),
          Groupes(),
          SuperGroupes(),
          Robots(),
          Favoris()
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Color(0xff152128),
          child: ListView(
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xff152128),
                ),
                child: Padding(
                  padding: EdgeInsets.all(5.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          CircleAvatar(
                            maxRadius: 25,
                            backgroundImage: AssetImage("images/9.png"),
                          ),
                          Column(
                            children: <Widget>[
                              Icon(
                                Icons.brightness_7,
                                color: Colors.white,
                                size: 25,
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              CircleAvatar(
                                maxRadius: 15,
                                backgroundColor: Colors.blue,
                                child: Icon(
                                  Icons.bookmark,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 0, left: 0),
                        child: Text(
                          'Laris',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            '+225 40 31 92 51',
                            style: TextStyle(
                              color: Colors.white54,
                            ),
                          ),
                          Icon(
                            Icons.arrow_drop_down,
                            color: Colors.white,
                            size: 30,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: Color(0xff102128),
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.group,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Nouveau groupe',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Nouvel échange secret',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Divider(
                      color: Colors.black,
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.person,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Contacts',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.location_on,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Personnes à proximité',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.bookmark_border,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Messages enregistrés',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.call,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Appels',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.folder_open,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Categories',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Divider(
                      color: Colors.black,
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.settings,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Paramètres',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.add_circle_outline,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'Paramètre Plus',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ListTile(
                      leading: IconButton(
                          icon: Icon(
                            Icons.help_outline,
                            color: Colors.grey,
                          ),
                          onPressed: () {}),
                      title: Text(
                        'FAQ Ghost Chat',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.blueAccent[300],
          child: Icon(
            Icons.edit,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pushNamed(context, "newMsg");
          }),
    );
  }
}
