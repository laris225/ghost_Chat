import 'package:flutter/material.dart';

class WidgNewMsg extends StatelessWidget {
  final String img;
  final String name;
  final String message;
  final String date;
  final String nmb;
  WidgNewMsg({this.img, this.name, this.message, this.date, this.nmb});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 10),
      width: MediaQuery.of(context).size.width,
      color: Color(0xff102128),
      child: Column(
        children: <Widget>[
          // Container(
          //   child: Row(
          //     children: <Widget>[
          //       IconButton(
          //           icon: Icon(
          //             Icons.people_outline,
          //             color: Colors.grey,
          //           ),
          //           onPressed: () {}),
          //       Text(
          //         "Nouveau groupe",
          //         style: TextStyle(color: Colors.white),
          //       ),
          //     ],
          //   ),
          // ),
          Container(
            color: Color(0xff102128),
            height: 60,
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      child: CircleAvatar(
                        maxRadius: 25,
                        backgroundImage: AssetImage(img),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          name,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text(
                                "en ligne à ",
                                style: TextStyle(color: Colors.grey),
                              ),
                              Text(
                                date,
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
