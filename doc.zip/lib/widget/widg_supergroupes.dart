import 'package:flutter/material.dart';

class WidgSuperGroup extends StatelessWidget {
  final String img;
  final String name;
  final String message;
  final String date;
  final String nmb;

  WidgSuperGroup({this.img, this.name, this.message, this.date, this.nmb});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 10),
      width: MediaQuery.of(context).size.width,
      color: Color(0xff102128),
      child: Column(
        children: <Widget>[
          Container(
            color: Color(0xff102128),
            height: 60,
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    CircleAvatar(
                      maxRadius: 25,
                      backgroundImage: AssetImage(img),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          name,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Icon(
                                Icons.check,
                                size: 15,
                                color: Colors.blue,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width / 1.65,
                                child: Text(
                                  message,
                                  style: TextStyle(color: Colors.grey),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      date,
                      style: TextStyle(color: Colors.white),
                    ),
                    CircleAvatar(
                      radius: 15,
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      child: Text(
                        nmb,
                        style: TextStyle(color: Colors.black),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 95, right: 10),
            child: Divider(),
          ),
        ],
      ),
    );
  }
}
