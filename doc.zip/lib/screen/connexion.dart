import 'package:flutter/material.dart';

class Connexion extends StatelessWidget {
  const Connexion({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff152128),
        title: Text("Votre téléphone"),
        actions: <Widget>[
          IconButton(
              icon: Icon(
                Icons.security,
                color: Colors.white,
              ),
              onPressed: null),
          IconButton(
              icon: Icon(
                Icons.language,
                color: Colors.white,
              ),
              onPressed: null),
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Color(0xff102128),
        child: Column(
          children: <Widget>[
            Column(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.only(left: 15, top: 30),
                      child: Text(
                        "Pays",
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 15),
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: TextField(
                        textAlign: TextAlign.start,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Côte d'Ivoire",
                            hintStyle: TextStyle(color: Colors.white)),
                      ),
                    ),
                    Container(
                      height: 1,
                      width: MediaQuery.of(context).size.width / 1.1,
                      color: Colors.black,
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(left: 15),
                          width: 100,
                          height: 50,
                          child: TextField(
                            textAlign: TextAlign.start,
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: "+ 225",
                                hintStyle: TextStyle(color: Colors.white)),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 15),
                          width: 213,
                          height: 50,
                          // decoration: BoxDecoration(
                          //     border: Border(
                          //         bottom: BoxBorder.lerp(
                          //             BoxBorder, BoxBorder, 10.5))
                          //     // all(color: Colors.white, width: 1),
                          //     ),
                          child: TextField(
                            textAlign: TextAlign.start,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Numéro de téléphone",
                              hintStyle: TextStyle(color: Colors.grey),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      height: 1,
                      width: MediaQuery.of(context).size.width / 1.1,
                      color: Colors.black,
                    ),
                  ],
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 20),
                  width: MediaQuery.of(context).size.width / 1.2,
                  child: Text(
                    "Nous enverons un SMS avec un code de confirmation à votre numéro de téléphone.",
                    style: TextStyle(color: Colors.grey, fontSize: 15),
                  ),
                ),
              ],
            ),
            MediaQuery.of(context).orientation == Orientation.portrait
                ? Btn(context, 45)
                : Btn(context, 180),
          ],
        ),
      ),
    );
  }
}

Widget Btn(BuildContext context, double marge) {
  return InkWell(
    onTap: () {
      Navigator.pushNamed(context, 'confirme');
    },
    child: Container(
      margin: EdgeInsets.only(top: 200),
      alignment: Alignment.center,
      width: 200,
      height: 45,
      child: Text(
        "Suivant",
        style: TextStyle(
            fontWeight: FontWeight.bold, color: Colors.black, fontSize: 17),
      ),
      decoration: BoxDecoration(
        color: Colors.red,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xff5eacf6), Color(0xff26559b)],
        ),
        borderRadius: BorderRadius.circular(5),
      ),
    ),
  );
}
