import 'package:flutter/material.dart';

import '../widget/widg_utilisateurs.dart';
import '../providers/data/data.dart';

class Utilisateurs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: userData.length,
        itemBuilder: (context, i) {
          return InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'message', arguments: {
                "nom": messageData[i]["nameData"],
                "photo": messageData[i]["imgData"],
                "statut": messageData[i]["stautData"],
              });
            },
            child: WidgUtilisateurs(
                img: userData[i]["imgData"],
                name: userData[i]["nameData"],
                message: userData[i]["msgData"],
                date: userData[i]["dateSendData"],
                nmb: userData[i]["nmbData"]),
          );
        });
  }
}
