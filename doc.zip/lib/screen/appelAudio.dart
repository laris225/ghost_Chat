import 'package:flutter/material.dart';

class AppelAudio extends StatelessWidget {
  const AppelAudio({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff152128),
        leading: IconButton(
            icon: Icon(
              Icons.close,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pushNamed(context, 'message');
            }),
        title: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 55),
          child: Text(
            "Appel vocal",
            style: TextStyle(color: Colors.white),
          ),
        ),
        elevation: 0,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/6.png"), fit: BoxFit.cover),
        ),
        child: Column(
          children: <Widget>[
            Container(
              height: 80,
              color: Colors.blue.withOpacity(0.1),
              alignment: Alignment.center,
              child: Text(
                "Prunelle",
                style: TextStyle(fontSize: 25),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 300),
              child: Container(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Icon(
                            Icons.mic,
                            size: 30,
                          ),
                          Text("Mute"),
                        ],
                      ),
                      Column(
                        children: <Widget>[
                          Icon(
                            Icons.volume_up,
                            size: 30,
                          ),
                          Text("Haut parleur"),
                        ],
                      ),
                      Column(
                        children: <Widget>[
                          Icon(
                            Icons.videocam,
                            size: 30,
                          ),
                          Text("Video"),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Column(
              children: <Widget>[
                FloatingActionButton(
                  child: Icon(
                    Icons.call_end,
                    color: Colors.white,
                  ),
                  backgroundColor: Colors.red,
                  onPressed: () {
                    Navigator.pushNamed(context, 'message');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
