import 'package:flutter/material.dart';

class Confirme extends StatelessWidget {
  const Confirme({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff152128),
        title: Text("Corfimation Code"),
        actions: <Widget>[
          IconButton(
              icon: Icon(
                Icons.more_vert,
                color: Colors.white,
              ),
              onPressed: null),
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Color(0xff102128),
        child: Column(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.only(left: 15, top: 30, bottom: 10),
              child: Text(
                "Code",
                style: TextStyle(color: Colors.white),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15),
              width: MediaQuery.of(context).size.width,
              height: 50,
              child: TextField(
                textAlign: TextAlign.start,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Entrer le code",
                    hintStyle: TextStyle(color: Colors.grey)),
              ),
            ),
            Container(
              height: 2,
              width: MediaQuery.of(context).size.width / 1,
              color: Colors.blue,
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 20),
              width: 330,
              child: Text(
                "Nous vous avons envoyé un code d'activation par SMS sur le numéro +225 40 31 92 51.",
                style: TextStyle(color: Colors.grey),
              ),
            ),
            Container(
              child: Text(
                "Vous n'avez pas reçu le code ?",
                style: TextStyle(color: Colors.blue[200]),
              ),
            ),
            MediaQuery.of(context).orientation == Orientation.portrait
                ? Btn(context, 45)
                : Btn(context, 180),
          ],
        ),
      ),
    );
  }
}

Widget Btn(BuildContext context, double marge) {
  return InkWell(
    onTap: () {
      Navigator.pushNamed(context, 'homePage');
    },
    child: Container(
      margin: EdgeInsets.only(top: 200),
      alignment: Alignment.center,
      width: 200,
      height: 45,
      child: Text(
        "Connexion",
        style: TextStyle(
            fontWeight: FontWeight.bold, color: Colors.black, fontSize: 17),
      ),
      decoration: BoxDecoration(
        color: Colors.red,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xff5eacf6), Color(0xff26559b)],
        ),
        borderRadius: BorderRadius.circular(5),
      ),
    ),
  );
}
