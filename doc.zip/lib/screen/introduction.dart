import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_page_indicator/flutter_page_indicator.dart';

class Introduction extends StatefulWidget {
  Introduction({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _Introduction createState() => new _Introduction();
}

class _Introduction extends State<Introduction> {
  double size = 10.0;
  double activeSize = 10.0;

  PageController controller;

  @override
  void initState() {
    controller = new PageController();
    super.initState();
  }

  @override
  void didUpdateWidget(Introduction oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    var children = <Widget>[
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xff5eadf6),
              ),
              child: Icon(
                FontAwesomeIcons.telegramPlane,
                size: 50,
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Ghost Chat",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 280,
              height: 60,
              child: Text(
                "Find deals for any season from cosy country homes to city flats",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 180,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(
                    image: AssetImage("images/intro2.png"), fit: BoxFit.cover),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Rapide",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 280,
              height: 60,
              child: Text(
                "Délivrer vos messages plus rapidement qu'aucune autre application",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 180,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(
                    image: AssetImage("images/intro3.png"), fit: BoxFit.cover),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Gratuit",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 270,
              height: 60,
              child: Text(
                "Ghost Chat sera toujours gratuit. Pas de Publicités. Pas de frais d'inscription.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 180,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(
                    image: AssetImage("images/intro4.png"), fit: BoxFit.cover),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Puissant",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 280,
              height: 60,
              child: Text(
                "Ghost Chat n'a pas de limites sur la taille de vos échanges et de vos médias",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 180,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(
                    image: AssetImage("images/intro5.png"), fit: BoxFit.cover),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Sécurisé",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 290,
              height: 60,
              child: Text(
                "Ghost Chat garde vos messages à l'abri des attaques pirates.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 200,
              height: 180,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(
                    image: AssetImage("images/intro6.png"), fit: BoxFit.cover),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Text(
              "Cloud",
              style: TextStyle(
                  fontSize: 40, color: Colors.white, fontFamily: "Billabong"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10, bottom: 20),
              width: 280,
              height: 60,
              child: Text(
                "Ghost Chat vous permet d'accéder à vos messages depuis plusieurs appareils.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    ];
    return new Scaffold(
      backgroundColor: Color(0xff152128),
      body: Column(
        children: <Widget>[
          new Container(
            height: MediaQuery.of(context).size.height / 1.5,
            width: MediaQuery.of(context).size.width,
            child: new Stack(
              children: <Widget>[
                new PageView(
                  controller: controller,
                  children: children,
                ),
                SizedBox(
                  height: 30,
                ),
                new Align(
                  alignment: Alignment.bottomCenter,
                  child: new PageIndicator(
                    layout: PageIndicatorLayout.DROP,
                    size: size,
                    activeSize: activeSize,
                    controller: controller,
                    space: 8.0,
                    count: 6,
                    color: Colors.white,
                    activeColor: Colors.blue,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50,
          ),
          MediaQuery.of(context).orientation == Orientation.portrait
              ? Btn(context, 45)
              : Btn(context, 180),
        ],
      ),
    );
  }
}

Widget Btn(BuildContext context, double marge) {
  return InkWell(
    onTap: () {
      Navigator.pushNamed(context, 'connexion');
    },
    child: Container(
      alignment: Alignment.center,
      width: MediaQuery.of(context).size.width / 1.4,
      height: 45,
      child: Text(
        "Démarrer une conversation",
        style: TextStyle(
            fontWeight: FontWeight.bold, color: Colors.black, fontSize: 17),
      ),
      decoration: BoxDecoration(
        color: Colors.red,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xff5eacf6), Color(0xff26559b)],
        ),
        borderRadius: BorderRadius.circular(5),
      ),
    ),
  );
}
