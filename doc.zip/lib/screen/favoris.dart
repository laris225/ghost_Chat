import 'package:flutter/material.dart';

class Favoris extends StatelessWidget {
  const Favoris({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Color(0xff102128),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            "Aucun Favoris",
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
          ),
          SizedBox(
            height: 8,
          ),
          Container(
            alignment: Alignment.center,
            width: 250,
            child: Text(
              "Pour ajouter n'importe quel chat à cette liste, appuyer simplement sur un chat et maintenez-le enfoncé, puis cliquez sur 'Ajouter aux favoris'.",
              style: TextStyle(color: Colors.grey, fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }
}
